package com.example.springsecurity.enumm;

public enum Role {
    ROLE_USER, ROLE_ADMIN
}
