package com.example.springsecurity.services;

import com.example.springsecurity.enumm.Status;
import com.example.springsecurity.models.Order;
import com.example.springsecurity.repositories.OrderRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional(readOnly = true)
public class OrderService {
    public final OrderRepository orderRepository;

    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public Order getOrderId(int id){
        Optional<Order> order = orderRepository.findById(id);
        return order.orElse(null);
    }

//    @Transactional
//    public void updateOrder(int id, int status) {
////        order.setId(id);
//        orderRepository.updateOrderStatus(id,status);
//    }

    @Transactional
    public void updateOrder(int id, String status) {
//        order.setId(id);
        Order order = getOrderId(id);
        order.setStatus(Status.valueOf(status));
        orderRepository.save(order);
     //   orderRepository.updateOrderStatus(id,status);
    }

    public Order orderByNumber(String number){
        List<Order> orders = orderRepository.findOrders();
        for(Order order : orders){
            String bitNumber = order.getNumber().substring(order.getNumber().length()-4);
            if(bitNumber.equals(number)){
                System.out.println(order);
                return order;
            }
        }
        return null;
    }
}
