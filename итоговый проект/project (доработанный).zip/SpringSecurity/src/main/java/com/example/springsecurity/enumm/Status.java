package com.example.springsecurity.enumm;

public enum Status {
    Принят, Оформлен, Ожидает, Получен
}
